"""Django models for recording user interactions with Nautobot."""

from django.core.exceptions import ValidationError
from django.db import models

from utilities.fields import ColorField

try:  # Netbox 2.9 and later
    from extras.models import ChangeLoggedModel
except ImportError:  # Netbox 2.8
    from utilities.models import ChangeLoggedModel

from .choices import AccessGrantTypeChoices


class CommandLog(models.Model):
    """Record of a single fully-executed Nautobot command.

    Incomplete commands (those requiring additional user input) should not be recorded,
    nor should any "help" commands or invalid command entries.
    """

    start_time = models.DateTimeField(null=True)
    runtime = models.DurationField(null=True)

    user_name = models.CharField(max_length=255, help_text="Invoking username")
    user_id = models.CharField(max_length=255, help_text="Invoking user ID")
    platform = models.CharField(max_length=64, help_text="Chat platform")
    platform_color = ColorField()

    command = models.CharField(max_length=64, help_text="Command issued")
    subcommand = models.CharField(max_length=64, help_text="Sub-command issued")

    def __str__(self):
        """String representation of a CommandLog entry."""
        return f"{self.user_name} on {self.platform}: {self.command} {self.subcommand}"

    class Meta:
        """Meta-attributes of a CommandLog."""

        ordering = ["start_time"]


class AccessGrant(ChangeLoggedModel):
    """Record of a single form of access granted to the chatbot."""

    command = models.CharField(max_length=64, help_text="Enter <tt>*</tt> to grant access to all commands")
    subcommand = models.CharField(
        max_length=64, help_text="Enter <tt>*</tt> to grant access to all subcommands of the given command",
    )

    grant_type = models.CharField(max_length=32, choices=AccessGrantTypeChoices)

    name = models.CharField(max_length=255, help_text="Organization name, channel name, or user name")
    value = models.CharField(
        max_length=255,
        help_text=(
            "Corresponding ID value to grant access to.<br>"
            "Enter <tt>*</tt> to grant access to all organizations, channels, or users"
        ),
    )

    def clean(self):
        """Model validation logic."""
        super().clean()
        if self.command == "*" and self.subcommand != "*":
            raise ValidationError("Use of a command wildcard with a non-wildcard subcommand is not permitted")

    def __str__(self):
        """String representation of an AccessGrant."""
        return f'cmd: "{self.command} {self.subcommand}", {self.grant_type}: "{self.name}" ({self.value})'

    class Meta:
        """Meta-attributes of an AccessGrant."""

        ordering = ["command", "subcommand", "grant_type"]
