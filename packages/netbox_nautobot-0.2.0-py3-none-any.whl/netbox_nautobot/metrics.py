"""Nautobot plugin metrics exposed through netbox_metrics_ext."""

from prometheus_client.core import CounterMetricFamily


def metric_commands():
    """Report on the history of command usage."""
    # pylint: disable=import-outside-toplevel
    from .models import CommandLog
    from .workers import get_workers
    from .workers.base import COMMANDS

    counters = CounterMetricFamily(
        "nautobot_commands", "Count of commands issued via Nautobot chatbot", labels=["command", "subcommand"],
    )

    get_workers()

    for command in sorted(COMMANDS):
        if not COMMANDS[command].get("subcommands"):
            # Command with no subcommands
            counters.add_metric([command, ""], CommandLog.objects.filter(command=command).count())
            continue
        for subcommand in sorted(COMMANDS[command]["subcommands"]):
            counters.add_metric(
                [command, subcommand], CommandLog.objects.filter(command=command, subcommand=subcommand).count()
            )

    yield counters

    # TODO: I'd also like to yield a Histogram showing how long each command took to execute (command_log.runtime)
    # but HistogramMetricFamily.add_metric() is beyond my understanding.
