"""Django FilterSet classes for Nautobot."""

from django_filters import FilterSet

from netbox_nautobot.models import CommandLog, AccessGrant


class CommandLogFilter(FilterSet):
    """FilterSet for filtering a set of CommandLog objects."""

    class Meta:
        """Metaclass attributes of CommandLogFilter."""

        model = CommandLog
        exclude = ["id", "platform_color"]


class AccessGrantFilter(FilterSet):
    """FilterSet for filtering a set of AccessGrant objects."""

    class Meta:
        """Metaclass attributes of AccessGrantFilter."""

        model = AccessGrant
        exclude = ["id", "name"]
