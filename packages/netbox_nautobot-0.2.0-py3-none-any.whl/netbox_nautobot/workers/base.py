"""Base functionality for any worker implementation."""

from datetime import datetime, timezone
import inspect
from functools import wraps

from netbox_nautobot.models import CommandLog

COMMANDS = {}
"""Registry of commands and subcommands.

Populated by calling netbox_nautobot.workers.get_workers()

COMMANDS = {
  'command': {
    'doc': "docstring"
    'function': <function object>
    'subcommands': {
       'subcommand_1': {
          'worker': worker_function,
          'params': [],
          'doc': "docstring"
       },
       'subcommand_2': {
          'worker': worker_function,
          'params': [],
          'doc': "docstring"
       },
    },
  },
  'command_2': {
    ...
  }
}
"""


def subcommand_of(command):
    """Decorator to register a function as a subcommand of a given command.

    NOTE: The return value of the subcommand function is used to influence command logging for metrics and such:
    - True or similar value: the command ran to completion and should be logged as such
    - False or similar value: the command did not actually run (additional input is needed from the user, etc.) and
      so, to reduce noise, it should not be logged.

    This decorator also does some magic to allow for optional positional arguments, so that the function can be called
    while only specifying some positional args (those unspecified will default to None). The first argument that
    this function takes must be the Dispatcher instance that the subcommand will use to communicate back to the user;
    all other positional arguments will be strings or None.

    ::

        @subcommand_of("command")
        def subcommand_name(dispatcher, arg_1, arg_2, arg_3):
            pass

        # Equivalent to calling subcommand_name(dispatcher, None, None, None)
        COMMANDS["command"]["subcommands"]["subcommand_name"]["worker"](dispatcher)
        # Equivalent to calling subcommand_name(dispatcher, "alpha", "beta", None)
        COMMANDS["command"]["subcommands"]["subcommand_name"]["worker"](dispatcher, "alpha", "beta")

    This is designed to work in combination with :func:`handle_subcommands`, below.
    """

    def subcommand(func):
        """Constructs the wrapper function for the decorated function."""
        sig = inspect.signature(func)
        # What are the positional args of func?
        params = [p for p in sig.parameters.values() if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)]

        @wraps(func)
        def wrapper(*args, **kwargs):
            """Fill in None values for any omitted args, then call the decorated function."""
            args = list(args)
            while len(args) < len(params):
                args.append(None)
            return func(*args, **kwargs)

        # Register this function in the COMMANDS dictionary as a subcommand
        subcommand_name = func.__name__.replace("_", "-")
        # See issue #20 - depending on code structure, it's possible we may process a subcommand before we
        # have actually processed its parent command. This is normal and we need to handle it.
        COMMANDS.setdefault(command, {}).setdefault("subcommands", {})[subcommand_name] = {
            "worker": wrapper,
            # params[0] is always the "dispatcher" instance, omit that
            "params": [p.name.replace("_", "-") for p in params[1:]],
            "doc": func.__doc__,
        }

        return wrapper

    return subcommand


def create_command_log(dispatcher_class, context, command, subcommand):
    """Helper function to instantiate a new CommandLog based on the given information."""
    return CommandLog(
        user_name=context.get("user_name", "UNKNOWN"),
        user_id=context.get("user_id", "UNKNOWN"),
        platform=dispatcher_class.platform_name,
        platform_color=dispatcher_class.platform_color,
        command=command,
        subcommand=subcommand,
        start_time=datetime.now(timezone.utc),
    )


def handle_subcommands(command, subcommand, params=(), dispatcher_class=None, context=None):
    """Generic worker function, to be used in combination with the @subcommand_of decorator above.

    ::

        @job("default")
        def commandname(subcommand, **kwargs):
            return handle_subcommands("command_name", subcommand, **kwargs)

        @subcommand_of("commandname")
        def first_subcommand(dispatcher, arg_1, arg_2):
            '''The first subcommand.'''
            pass

        @subcommand_of("commandname")
        def second_subcommand(dispatcher, arg_1):
            '''The second subcommand.'''
            pass

    chat client::

        > /commandname help
        "/commandname" subcommands:
        - /commandname first-subcommand [arg-1] [arg-2]  The first subcommand
        - /commandname second-subcommand [arg-1]         The second subcommand
    """
    if not context:
        context = {}
    command_log = create_command_log(dispatcher_class, context, command, subcommand)
    dispatcher = dispatcher_class(context=context)

    if subcommand == "help" or not subcommand:
        message = f"I know the following `{dispatcher.command_prefix}{command}` subcommands:\n"
        for subcmd, entry in COMMANDS[command].get("subcommands", {}).items():
            message += (
                f"- `{dispatcher.command_prefix}{command} {subcmd} "
                f"{' '.join(f'[{param}]' for param in entry['params'])}`\t{entry['doc']}\n"
            )
        # Present help message, do not save command_log
        dispatcher.send_markdown(message, ephemeral=True)
        return False

    if subcommand not in COMMANDS.get(command, {}).get("subcommands", {}):
        # Usage error, do not save command_log
        dispatcher.send_error(f'I don\'t know the {dispatcher.command_prefix}{command} subcommand "{subcommand}"')
        return False

    if params and params[0] == "help":
        entry = COMMANDS[command]["subcommands"][subcommand]
        message = (
            f"Usage: `{dispatcher.command_prefix}{command} {subcommand} "
            f"{' '.join(f'[{param}]' for param in entry['params'])}`\n{entry['doc']}"
        )
        # Present usage message, do not save command_log
        dispatcher.send_markdown(message, ephemeral=True)
        return False

    try:
        # A subcommand should return a truthy value if it did something meaningful,
        # and a falsy value if it didn't (e.g., it's just prompting the user for more information)
        result = COMMANDS[command]["subcommands"][subcommand]["worker"](dispatcher, *params)
        if result:
            command_log.runtime = datetime.now(timezone.utc) - command_log.start_time
            command_log.save()
    except Exception as exc:  # pylint:disable=broad-except
        dispatcher.send_error(f"An internal error occurred:\n{exc}")
        # Sure, we might as well save the command log in this case...
        command_log.runtime = datetime.now(timezone.utc) - command_log.start_time
        command_log.save()
        raise

    return result
