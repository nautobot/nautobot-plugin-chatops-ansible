"""Workers module for the netbox_nautobot NetBox plugin.

The functions in this module provide back-end worker logic that is totally ignorant
of the differences between various chat platforms. They receive generic data from
one of the platform-specific ``views``, handle it appropriately, then dispatch it
back to the chat using the provided ``dispatchers`` instance's generic API.
"""

import pkg_resources
import logging

from .base import COMMANDS

logger = logging.getLogger("rq.worker")


def get_workers():
    """Populate and return the COMMANDS dictionary with all known workers."""
    if COMMANDS:
        # Already populated, don't regenerate it
        return COMMANDS

    # See issue #20 - if there are subcommands of multiple top-level commands in a single module,
    # that whole module gets loaded when we call worker.load() below, which includes the subcommands
    # of commands we haven't yet processed.
    # In other words, we can't guarantee that we process a command before we process its subcommands,
    # so don't treat the subcommand-before-command case as an error.

    for worker in pkg_resources.iter_entry_points("nautobot.workers"):
        # See above. However, we still should never have two command worker functions registered under the same name.
        command_func = worker.load()
        if worker.name in COMMANDS and "function" in COMMANDS[worker.name] and COMMANDS[worker.name]["function"]:
            if COMMANDS[worker.name]["function"] == command_func:
                logger.warning("Command worker function '%s' was processed twice. This should not happen", worker.name)
            else:
                logger.error("Duplicate worker name '%s' detected! Check for redundant plugins", worker.name)
            continue
        if worker.name not in COMMANDS:
            COMMANDS[worker.name] = {"subcommands": {}}
        COMMANDS[worker.name]["function"] = command_func
        COMMANDS[worker.name]["doc"] = command_func.__doc__

    return COMMANDS


def workers_help(prefix=""):
    """Construct a top-level "help" menu for the bot to use."""
    return "I know the following commands:\n" + "\n".join(
        f"- `{prefix}{name}`\t{data['doc']}" for name, data in get_workers().items()
    )


def parse_command_string(command_string):
    """Parse a command string into (command, subcommand, *args).

    Any of the following syntaxes are valid:
    - command sub-command
    - command sub-command arg1 arg2
    - command-sub-command
    - command-sub-command arg1 arg2

    Note that a command's name never contains internal hyphens, although a subcommand's name may.
    """
    # Strip leading/trailing whitespace
    command_string = command_string.strip()
    if " " in command_string:
        command, subcommand = command_string.split(maxsplit=1)
        if "-" in command:
            text = subcommand
            command, subcommand = command.split(sep="-", maxsplit=1)
        elif " " in subcommand:
            subcommand, text = subcommand.split(maxsplit=1)
        else:
            text = ""
    elif "-" in command_string:
        command, subcommand = command_string.split(sep="-", maxsplit=1)
        text = ""
    else:
        command = command_string
        subcommand = ""
        text = ""

    args = text.split()
    return command, subcommand, args
