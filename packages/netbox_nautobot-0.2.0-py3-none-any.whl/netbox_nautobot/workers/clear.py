"""Simple worker function for "clearing" the chat screen by sending a block of blank text."""

from datetime import datetime, timezone

from django_rq import job

from .base import create_command_log


@job("default")
def clear(subcommand, dispatcher_class=None, context=None, **kwargs):
    """Scroll the chat history out of view."""
    # This command is somewhat unique as it doesn't have any subcommands or parameters.
    # Hence we don't use the usual handle_subcommands() / subcommand_of() functions used in more complex workers.
    command_log = create_command_log(dispatcher_class, context, "clear", subcommand)
    dispatcher = dispatcher_class(context=context)

    # 1) Markdown ignores single newlines, you need two consecutive ones to get a rendered newline
    # 2) If you have more than two consecutive newlines, they get collapsed together, so we need something between them
    # 3) The below is using " " (Unicode NO-BREAK SPACE) rather than an ordinary " " (space)
    dispatcher.send_markdown("Clearing..." + " \n\n" * 50 + "...Cleared!", ephemeral=True)

    command_log.runtime = datetime.now(timezone.utc) - command_log.start_time
    command_log.save()

    return True
