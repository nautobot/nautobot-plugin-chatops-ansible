"""Worker functions for interacting with NetBox."""

from django.core.exceptions import ValidationError
from django.db.models import Count
from django_rq import job

from dcim.choices import DeviceStatusChoices
from dcim.models import Device, Site, DeviceRole, DeviceType, Manufacturer, Rack
from circuits.models import Circuit, CircuitType, Provider, CircuitTermination

from .base import subcommand_of, handle_subcommands

NETBOX_LOGO_PATH = "nautobot/NetBoxLogoSquare.png"
NETBOX_LOGO_ALT = "NetBox Logo"


@job("default")
def netbox(subcommand, **kwargs):
    """Interact with NetBox."""
    return handle_subcommands("netbox", subcommand, **kwargs)


def prompt_for_device(action_id, help_text, dispatcher, devices=None):
    """Prompt the user to select a valid device from a drop-down menu."""
    # In the previous implementation, we grouped the devices into subgroups by site.
    # Unfortunately, while this is possible in Slack, the Adaptive Cards spec (MS Teams / WebEx Teams) can't do it.
    if devices is None:
        devices = Device.objects.all().order_by("site", "name")
    if not devices:
        dispatcher.send_error("No devices were found")
        return False
    choices = [(f"{device.site.name}: {device.name}", device.name) for device in devices]
    return dispatcher.prompt_from_menu(action_id, help_text, choices)


def prompt_for_device_filter_type(action_id, help_text, dispatcher):
    """Prompt the user to select a valid device filter type from a drop-down menu."""
    choices = [
        ("Name", "name"),
        ("Site", "site"),
        ("Role", "role"),
        ("Model", "model"),
        ("Manufacturer", "manufacturer"),
    ]
    return dispatcher.prompt_from_menu(action_id, help_text, choices)


def netbox_logo(dispatcher):
    """Construct an image_element containing the locally hosted NetBox logo."""
    return dispatcher.image_element(dispatcher.static_url(NETBOX_LOGO_PATH), alt_text=NETBOX_LOGO_ALT)


@subcommand_of("netbox")
def get_device_status(dispatcher, device_name):
    """Get the status of a device in NetBox."""
    if not device_name:
        prompt_for_device("netbox get-device-status", "Get NetBox Device Status", dispatcher)
        return False  # command did not run to completion and therefore should not be logged

    try:
        device = Device.objects.get(name=device_name)
    except Device.DoesNotExist:
        dispatcher.send_error(f"I don't know device '{device_name}'")
        prompt_for_device("netbox get-device-status", "Get NetBox Device Status", dispatcher)
        return False  # command did not run to completion and therefore should not be logged

    blocks = [
        *dispatcher.command_response_header(
            "netbox", "get-device-status", [("Name", device_name)], "device status", netbox_logo(dispatcher),
        ),
        dispatcher.markdown_block(f"The status of {dispatcher.bold(device_name)} is {dispatcher.bold(device.status)}"),
    ]

    dispatcher.send_blocks(blocks)
    return True


@subcommand_of("netbox")
def change_device_status(dispatcher, device_name, status):
    """Set the status of a device in NetBox."""
    if not device_name:
        prompt_for_device("netbox change-device-status", "Change NetBox Device Status", dispatcher)
        return False  # command did not run to completion and therefore should not be logged

    try:
        device = Device.objects.get(name=device_name)
    except Device.DoesNotExist:
        dispatcher.send_error(f"I don't know device '{device_name}'")
        prompt_for_device("netbox change-device-status", "Change NetBox Device Status", dispatcher)
        return False  # command did not run to completion and therefore should not be logged

    if not status:
        dispatcher.prompt_from_menu(
            f"netbox change-device-status {device_name}",
            f"Change NetBox Device Status for {device_name}",
            [(choice[1], choice[0]) for choice in DeviceStatusChoices.CHOICES],
            default=(device.status.capitalize(), device.status),
            confirm=True,
        )
        return False  # command did not run to completion and therefore should not be logged

    device.status = status
    try:
        device.clean_fields()
    except ValidationError:
        dispatcher.send_error(f"I'm sorry, but {status} is not a valid device status value.")
        return False  # command did not run to completion and therefore should not be logged

    device.save()
    dispatcher.send_blocks(
        [
            *dispatcher.command_response_header(
                "netbox",
                "change-device-status",
                [("Device name", device_name), ("Status", status)],
                "device status change",
                netbox_logo(dispatcher),
            ),
            dispatcher.markdown_block(
                f"NetBox status for {dispatcher.bold(device_name)} successfully changed to {dispatcher.monospace(status)}."
            ),
        ]
    )
    return True


@subcommand_of("netbox")
def get_device_facts(dispatcher, device_name):
    """Get detailed facts about a device from NetBox in YAML format."""
    if not device_name:
        prompt_for_device("netbox get-device-facts", "Get NetBox Device Facts", dispatcher)
        return False  # command did not run to completion and therefore should not be logged

    try:
        device = Device.objects.get(name=device_name)
    except Device.DoesNotExist:
        dispatcher.send_error(f"I don't know device '{device_name}'")
        prompt_for_device("netbox get-device-facts", "Get NetBox Device Facts", dispatcher)
        return False  # command did not run to completion and therefore should not be logged

    dispatcher.send_blocks(
        dispatcher.command_response_header(
            "netbox", "get-device-facts", [("Name", device_name)], "fact data", netbox_logo(dispatcher),
        )
    )

    # We use send_markdown() rather than including this as a markdown_block() in the above send_blocks() call
    # because MS Teams doesn't support the ```preformatted text``` markdown in blocks, but does in standalone messages.
    dispatcher.send_markdown(
        "```\n---\n"
        f"name: {device.name}\n"
        f"manufacturer: {device.device_type.manufacturer.name}\n"
        f"model: {device.device_type.model}\n"
        f"role: {device.device_role.name if device.device_role else '~'}\n"
        f"platform: {device.platform.name if device.platform else '~'}\n"
        f"primary_ip: {device.primary_ip.address if device.primary_ip else '~'}\n"
        f"created: {device.created}\n"
        f"updated: {device.last_updated}\n"
        "```\n"
    )
    return True


@subcommand_of("netbox")
def get_devices(dispatcher, filter_type, filter_value):
    """Get a filtered list of devices from NetBox."""
    if not filter_type:
        prompt_for_device_filter_type("netbox get-devices", "Select a device filter", dispatcher)
        return False  # command did not run to completion and therefore should not be logged

    if not filter_value:
        if filter_type == "name":
            dispatcher.prompt_for_text(f"netbox get-devices {filter_type}", f"Enter device name", "Device name")
            return False  # command did not run to completion and therefore should not be logged
        elif filter_type == "site":
            choices = [(site.name, site.slug) for site in Site.objects.all()]
        elif filter_type == "role":
            choices = [(role.name, role.slug) for role in DeviceRole.objects.all()]
        elif filter_type == "model":
            choices = [(device_type.display_name, device_type.slug) for device_type in DeviceType.objects.all()]
        elif filter_type == "manufacturer":
            choices = [(manufacturer.name, manufacturer.slug) for manufacturer in Manufacturer.objects.all()]
        else:
            dispatcher.send_error(f"I don't know how to filter by {filter_type}")
            return False  # command did not run to completion and therefore should not be logged

        dispatcher.prompt_from_menu(f"netbox get-devices {filter_type}", f"Select a {filter_type}", choices)
        return False  # command did not run to completion and therefore should not be logged

    if filter_type == "name":
        devices = Device.objects.filter(name=filter_value)
    elif filter_type == "site":
        try:
            site = Site.objects.get(slug=filter_value)
        except Site.DoesNotExist:
            dispatcher.send_error(f"Site {filter_value} not found")
            return False  # command did not run to completion and therefore should not be logged
        devices = Device.objects.filter(site=site)
    elif filter_type == "role":
        try:
            role = DeviceRole.objects.get(slug=filter_value)
        except DeviceRole.DoesNotExist:
            dispatcher.send_error(f"Device role {filter_value} not found")
            return False  # command did not run to completion and therefore should not be logged
        devices = Device.objects.filter(device_role=role)
    elif filter_type == "model":
        try:
            device_type = DeviceType.objects.get(slug=filter_value)
        except DeviceType.DoesNotExist:
            dispatcher.send_error(f"Device type {filter_value} not found")
            return False  # command did not run to completion and therefore should not be logged
        devices = Device.objects.filter(device_type=device_type)
    elif filter_type == "manufacturer":
        # This one is a bit weird, as devices don't directly have a Manufacturer attribute,
        # but the previous implementation supported this filter, so here we go.
        # TODO: is there a better way?
        try:
            manufacturer = Manufacturer.objects.get(slug=filter_value)
        except Manufacturer.DoesNotExist:
            dispatcher.send_error(f"Manufacturer {filter_value} not found")
            return False  # command did not run to completion and therefore should not be logged
        device_types = DeviceType.objects.filter(manufacturer=manufacturer)
        devices = Device.objects.filter(device_type__in=device_types)
    else:
        dispatcher.send_error(f"I don't know how to filter by {filter_type}")
        return False  # command did not run to completion and therefore should not be logged

    if not devices:
        dispatcher.send_warning("Filtered device list is empty")
        return True  # command ran to completion, it just didn't have anything to report

    dispatcher.send_blocks(
        dispatcher.command_response_header(
            "netbox",
            "get-devices",
            [("Filter type", filter_type), ("Filter value", filter_value)],
            "device list",
            netbox_logo(dispatcher),
        )
    )

    header = ["Name", "Status", "Tenant", "Site", "Rack", "Role", "Type", "IP Address"]
    rows = [
        (
            device.name,
            device.status,
            str(device.tenant) if device.tenant else "",
            str(device.site),
            str(device.rack) if device.rack else "",
            device.device_role,
            device.device_type,
            str(device.primary_ip.address).split("/")[0] if device.primary_ip else "",
        )
        for device in devices
    ]

    dispatcher.send_large_table(header, rows)
    return True


@subcommand_of("netbox")
def get_rack(dispatcher, site_slug, rack_id):
    """Get information about a specific rack from NetBox."""
    if not site_slug:
        # Only include sites with a non-zero number of racks
        site_options = [
            (site.name, site.slug) for site in Site.objects.annotate(Count("racks")).filter(racks__count__gt=0)
        ]
        if not site_options:
            dispatcher.send_error("No sites with associated racks were found")
            return False
        dispatcher.prompt_from_menu("netbox get-rack", "Select a site", site_options)
        return False  # command did not run to completion and therefore should not be logged

    try:
        site = Site.objects.get(slug=site_slug)
    except Site.DoesNotExist:
        dispatcher.send_error(f"Site {site_slug} not found")
        return False  # command did not run to completion and therefore should not be logged

    if not rack_id:
        rack_options = [(rack.name, str(rack.id)) for rack in Rack.objects.filter(site=site)]
        if not rack_options:
            dispatcher.send_error(f"No racks associated with site {site_slug} were found")
            return False
        dispatcher.prompt_from_menu(f"netbox get-rack {site_slug}", "Select a rack", rack_options)
        return False  # command did not run to completion and therefore should not be logged

    rack_id = int(rack_id)
    try:
        rack = Rack.objects.get(id=rack_id)
    except Rack.DoesNotExist:
        dispatcher.send_error(f"Rack {rack_id} not found")
        return False  # command did not run to completion and therefore should not be logged

    # Slack limits a block to no more than 3000 characters of text, and also limits the max width of a Markdown block.
    # It also limits the length of a message to no more than 4000 characters.
    # So we'll send the header as a block, then the table itself as a "file" attachment, which has no length limit.

    dispatcher.send_blocks(
        dispatcher.command_response_header(
            "netbox",
            "get-rack",
            [("Site", site.name, site_slug), ("Rack", rack.name, str(rack_id))],
            "rack overview",
            netbox_logo(dispatcher),
        )
    )

    units = rack.get_rack_units()
    if not units:
        dispatcher.send_warning("Rack is empty")
        return True
    table = "\n".join(f"{unit['id']:2d} | {unit['device'].name if unit['device'] else ''}" for unit in units)
    dispatcher.send_snippet(table)
    return True


def prompt_for_circuit_filter_type(action_id, help_text, dispatcher):
    """Prompt the user to select a valid device filter type from a drop-down menu."""
    choices = [
        ("All (no filter)", "all"),
        ("Type", "type"),
        ("Provider", "provider"),
        ("Site", "site"),
    ]
    return dispatcher.prompt_from_menu(action_id, help_text, choices)


@subcommand_of("netbox")
def get_circuits(dispatcher, filter_type, filter_value):
    """Get a filtered list of circuits from NetBox."""
    if not filter_type:
        prompt_for_circuit_filter_type("netbox get-circuits", "Select a circuit filter", dispatcher)
        return False  # command did not run to completion and therefore should not be logged

    if filter_type != "all" and not filter_value:
        if filter_type == "type":
            choices = [(ctype.name, ctype.slug) for ctype in CircuitType.objects.all()]
        elif filter_type == "provider":
            choices = [(prov.name, prov.slug) for prov in Provider.objects.all()]
        elif filter_type == "site":
            choices = [(site.name, site.slug) for site in Site.objects.all()]
        else:
            dispatcher.send_error(f"I don't know how to filter by {filter_type}")
            return False  # command did not run to completion and therefore should not be logged

        if not choices:
            dispatcher.send_error(f"No matching entries found for {filter_type}")
            return False

        dispatcher.prompt_from_menu(f"netbox get-circuits {filter_type}", f"Select a circuit {filter_type}", choices)
        return False  # command did not run to completion and therefore should not be logged

    if filter_type == "all":
        circuits = Circuit.objects.all()
    elif filter_type == "type":
        try:
            ctype = CircuitType.objects.get(slug=filter_value)
        except Site.DoesNotExist:
            dispatcher.send_error(f"Circuit type {filter_value} not found")
            return False  # command did not run to completion and therefore should not be logged
        circuits = Circuit.objects.filter(type=ctype)
    elif filter_type == "provider":
        try:
            prov = Provider.objects.get(slug=filter_value)
        except Provider.DoesNotExist:
            dispatcher.send_error(f"Provider {filter_value} not found")
            return False  # command did not run to completion and therefore should not be logged
        circuits = Circuit.objects.filter(provider=prov)
    elif filter_type == "site":
        try:
            site = Site.objects.get(slug=filter_value)
        except Site.DoesNotExist:
            dispatcher.send_error(f"Site {filter_value} not found")
            return False  # command did not run to completion and therefore should not be logged
        # TODO is there a cleaner way to do this?
        terms = CircuitTermination.objects.filter(site=site)
        circuits = Circuit.objects.filter(terminations__in=terms)
    else:
        dispatcher.send_error(f"I don't know how to filter by {filter_type}")
        return False  # command did not run to completion and therefore should not be logged

    if not circuits:
        dispatcher.send_warning("Filtered circuit list is empty")
        return True

    filter_pairs = [("Filter type", filter_type)]
    if filter_value:
        filter_pairs.append(("Filter value", filter_value))

    dispatcher.send_blocks(
        dispatcher.command_response_header(
            "netbox", "get-circuits", filter_pairs, "circuit list", netbox_logo(dispatcher),
        )
    )

    header = ["ID", "Provider", "Type", "Status", "Tenant", "A Side", "Z Side", "Description"]
    rows = [
        (
            circuit.cid,
            str(circuit.provider) if circuit.provider else "",
            str(circuit.type),
            circuit.status,
            str(circuit.tenant) if circuit.tenant else "",
            str(circuit.termination_a.site) if circuit.termination_a else "",
            str(circuit.termination_z.site) if circuit.termination_z else "",
            circuit.description,
        )
        for circuit in circuits
    ]

    dispatcher.send_large_table(header, rows)
    return True


@subcommand_of("netbox")
def get_circuit_providers(dispatcher, *args):
    """Get a list of circuit providers."""
    providers = Provider.objects.all()

    dispatcher.send_blocks(
        dispatcher.command_response_header(
            "netbox", "get-circuit-providers", [], "circuit provider list", netbox_logo(dispatcher),
        )
    )

    header = ["Name", "ASN", "Account", "Circuits"]
    rows = [
        (prov.name, str(prov.asn) if prov.asn else "", prov.account, len(prov.circuits.all())) for prov in providers
    ]

    dispatcher.send_large_table(header, rows)
    return True
