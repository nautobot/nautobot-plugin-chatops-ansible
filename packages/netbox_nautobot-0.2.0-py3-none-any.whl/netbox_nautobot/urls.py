"""Django urlpatterns declaration for netbox_nautobot plugin."""

from django.urls import path

from extras.views import ObjectChangeLogView

from netbox_nautobot.models import AccessGrant
from netbox_nautobot.views import (
    NautobotHomeView,
    AccessGrantListView,
    AccessGrantView,
    AccessGrantCreateView,
    AccessGrantBulkDeleteView,
)

urlpatterns = [
    path("", NautobotHomeView.as_view(), name="home"),
    path("access/", AccessGrantListView.as_view(), name="accessgrant_list"),
    path(
        "access/<int:pk>/changelog/",
        ObjectChangeLogView.as_view(),
        name="accessgrant_changelog",
        kwargs={"model": AccessGrant},
    ),
    path("access/<int:pk>/edit/", AccessGrantView.as_view(), name="accessgrant_edit"),
    path("access/add/", AccessGrantCreateView.as_view(), name="accessgrant_add"),
    path("access/delete/", AccessGrantBulkDeleteView.as_view(), name="accessgrant_bulk_delete"),
]
