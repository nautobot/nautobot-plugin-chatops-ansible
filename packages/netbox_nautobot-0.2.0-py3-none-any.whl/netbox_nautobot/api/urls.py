"""Django urlpatterns declaration for netbox_nautobot plugin."""

from django.urls import path

from django.conf import settings
from netbox_nautobot.api.views.lookup import AccessLookupView


urlpatterns = [path("lookup/", AccessLookupView.as_view(), name="access_lookup")]

if settings.PLUGINS_CONFIG["netbox_nautobot"].get("enable_slack"):
    from netbox_nautobot.api.views.slack import SlackSlashCommandView, SlackInteractionView

    urlpatterns += [
        path("slack/slash_command/", SlackSlashCommandView.as_view(), name="slack_slash_command"),
        path("slack/interaction/", SlackInteractionView.as_view(), name="slack_interaction"),
    ]

if settings.PLUGINS_CONFIG["netbox_nautobot"].get("enable_ms_teams"):
    from netbox_nautobot.api.views.ms_teams import MSTeamsMessagesView

    urlpatterns += [
        path("ms_teams/messages/", MSTeamsMessagesView.as_view(), name="ms_teams_messages"),
    ]

if settings.PLUGINS_CONFIG["netbox_nautobot"].get("enable_webex_teams"):
    from netbox_nautobot.api.views.webex_teams import WebExTeamsView

    urlpatterns += [
        path("webex_teams/", WebExTeamsView.as_view(), name="webex_teams"),
    ]
