"""API Views module for the netbox_nautobot NetBox plugin.

The views implemented in this module act as endpoints for various chat platforms
to send requests and notifications to.
"""
