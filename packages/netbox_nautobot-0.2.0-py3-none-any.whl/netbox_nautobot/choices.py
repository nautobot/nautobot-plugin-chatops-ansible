"""ChoiceSet classes for Nautobot."""

from utilities.choices import ChoiceSet


class AccessGrantTypeChoices(ChoiceSet):
    """Choices for the AccessGrant grant_type field."""

    TYPE_ORGANIZATION = "organization"
    TYPE_CHANNEL = "channel"
    TYPE_USER = "user"

    CHOICES = (
        (TYPE_ORGANIZATION, "Organization"),
        (TYPE_CHANNEL, "Channel"),
        (TYPE_USER, "User"),
    )
