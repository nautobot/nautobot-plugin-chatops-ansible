"""Tests for Nautobot utility functions."""

from unittest.mock import patch

from django.test import TestCase

from netbox_nautobot.choices import AccessGrantTypeChoices
from netbox_nautobot.models import AccessGrant
from netbox_nautobot.utils import check_and_enqueue_command


class MockDispatcher:
    """Mock version of the Dispatcher interface."""

    error = None

    def __init__(self, *args, **kwargs):
        """Do nothing."""

    @classmethod
    def reset(cls):
        """Reset the class to baseline (no recorded error)."""
        cls.error = None
        return cls

    @classmethod
    def send_error(cls, message):
        """Record an error message."""
        cls.error = message


def nada():
    """No-op function for testing purposes."""


@patch("netbox_nautobot.utils.get_workers")
@patch("netbox_nautobot.utils.get_queue")
class TestCheckAndEnqueue(TestCase):
    """Verify that access grants are correctly implemented."""

    @staticmethod
    def setup_get_workers(mock_get_workers):
        """Per-test initialization of the mock_get_workers object, applicable to most test cases."""
        mock_get_workers.return_value = {"x": {"function": nada}, "y": {"function": nada}, "z": {"function": nada}}

    def test_default_deny(self, mock_get_queue, mock_get_workers):
        """With no AccessGrants in the database, all requests are denied by default."""
        self.setup_get_workers(mock_get_workers)
        mock_get_queue.reset_mock()
        check_and_enqueue_command(
            "x", "y", [], {"org_id": "11", "channel_id": "111", "user_id": "1111"}, MockDispatcher.reset(),
        )
        self.assertEqual(
            MockDispatcher.error, "Access to this bot and/or command is not permitted in organization 11",
        )
        mock_get_queue.assert_not_called()

        # Add an organization access grant
        AccessGrant.objects.create(
            command="*", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_ORGANIZATION, name="org1", value="11",
        )
        mock_get_queue.reset_mock()
        check_and_enqueue_command(
            "x", "y", [], {"org_id": "11", "channel_id": "111", "user_id": "1111"}, MockDispatcher.reset(),
        )
        self.assertEqual(
            MockDispatcher.error, "Access to this bot and/or command is not permitted in channel 111",
        )
        mock_get_queue.assert_not_called()

        # Add a channel access grant
        AccessGrant.objects.create(
            command="*", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_CHANNEL, name="channel1", value="111",
        )
        mock_get_queue.reset_mock()
        check_and_enqueue_command(
            "x", "y", [], {"org_id": "11", "channel_id": "111", "user_id": "1111"}, MockDispatcher.reset(),
        )
        self.assertEqual(
            MockDispatcher.error, "Access to this bot and/or command is not permitted by user 1111",
        )
        mock_get_queue.assert_not_called()

        # Add a user access grant - now things should be permitted
        AccessGrant.objects.create(
            command="*", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_USER, name="user1", value="1111",
        )
        mock_get_queue.reset_mock()
        check_and_enqueue_command(
            "x", "y", [], {"org_id": "11", "channel_id": "111", "user_id": "1111"}, MockDispatcher.reset(),
        )
        self.assertIsNone(MockDispatcher.error)
        mock_get_queue.assert_called_once()

    def setup_db(self):
        """Per-testcase database population for most test cases."""
        # Create some globally applicable access grants:
        AccessGrant.objects.create(
            command="*", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_ORGANIZATION, name="org1", value="11",
        )
        AccessGrant.objects.create(
            command="*", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_CHANNEL, name="channel1", value="111",
        )
        AccessGrant.objects.create(
            command="*", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_USER, name="user1", value="1111",
        )
        # And some per-command access grants:
        AccessGrant.objects.create(
            command="x", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_ORGANIZATION, name="org2", value="22",
        )
        AccessGrant.objects.create(
            command="x", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_CHANNEL, name="channel2", value="222",
        )
        AccessGrant.objects.create(
            command="x", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_USER, name="user2", value="2222",
        )
        # And some per-subcommand access grants:
        AccessGrant.objects.create(
            command="x", subcommand="a", grant_type=AccessGrantTypeChoices.TYPE_ORGANIZATION, name="org3", value="33",
        )
        AccessGrant.objects.create(
            command="x", subcommand="a", grant_type=AccessGrantTypeChoices.TYPE_CHANNEL, name="channel3", value="333",
        )
        AccessGrant.objects.create(
            command="x", subcommand="a", grant_type=AccessGrantTypeChoices.TYPE_USER, name="user3", value="3333",
        )
        # And some wildcard access grants:
        AccessGrant.objects.create(
            command="y", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_ORGANIZATION, name="any", value="*",
        )
        AccessGrant.objects.create(
            command="y", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_CHANNEL, name="any", value="*",
        )
        AccessGrant.objects.create(
            command="y", subcommand="*", grant_type=AccessGrantTypeChoices.TYPE_USER, name="any", value="*",
        )

    def test_permitted_globally(self, mock_get_queue, mock_get_workers):
        """A global access grant applies to all commands and subcommands."""
        self.setup_db()
        self.setup_get_workers(mock_get_workers)
        # user1/channel1/org1 are globally permitted
        for cmd, subcmd in [("x", "a"), ("x", "b"), ("y", "a"), ("z", "a")]:
            mock_get_queue.reset_mock()
            check_and_enqueue_command(
                cmd, subcmd, [], {"org_id": "11", "channel_id": "111", "user_id": "1111"}, MockDispatcher.reset(),
            )
            self.assertIsNone(MockDispatcher.error)
            mock_get_queue.assert_called_once()

    def test_permitted_command(self, mock_get_queue, mock_get_workers):
        """A per-command access grant applies to all subcommands under the command, and no others."""
        self.setup_db()
        self.setup_get_workers(mock_get_workers)
        # user2/channel2/org2 are explicitly permitted to subcommands of command "x"
        # all users/channels/orgs are permitted to subcommands of command "y"
        for cmd, subcmd in [("x", "a"), ("x", "b"), ("y", "a")]:
            mock_get_queue.reset_mock()
            check_and_enqueue_command(
                cmd, subcmd, [], {"org_id": "22", "channel_id": "222", "user_id": "2222"}, MockDispatcher.reset(),
            )
            self.assertIsNone(MockDispatcher.error)
            mock_get_queue.assert_called_once()
        for cmd, subcmd in [("z", "a")]:
            mock_get_queue.reset_mock()
            check_and_enqueue_command(
                cmd, subcmd, [], {"org_id": "22", "channel_id": "222", "user_id": "2222"}, MockDispatcher.reset(),
            )
            self.assertEqual(
                MockDispatcher.error, "Access to this bot and/or command is not permitted in organization 22",
            )
            mock_get_queue.assert_not_called()

    def test_permitted_subcommand(self, mock_get_queue, mock_get_workers):
        """A per-subcommand access grant applies that subcommands under that command, and no others."""
        self.setup_db()
        self.setup_get_workers(mock_get_workers)
        # user3/channel3/org3 are only permitted to subcommand "a" of command "x"
        # all users/channels/orgs are permitted to subcommands of command "y"
        for cmd, subcmd in [("x", "a"), ("y", "a")]:
            mock_get_queue.reset_mock()
            check_and_enqueue_command(
                cmd, subcmd, [], {"org_id": "33", "channel_id": "333", "user_id": "3333"}, MockDispatcher.reset(),
            )
            self.assertIsNone(MockDispatcher.error)
            mock_get_queue.assert_called_once()
        for cmd, subcmd in [("x", "b"), ("z", "a")]:
            mock_get_queue.reset_mock()
            check_and_enqueue_command(
                cmd, subcmd, [], {"org_id": "33", "channel_id": "333", "user_id": "3333"}, MockDispatcher.reset(),
            )
            self.assertEqual(
                MockDispatcher.error, "Access to this bot and/or command is not permitted in organization 33",
            )
            mock_get_queue.assert_not_called()

    def test_not_permitted_user(self, mock_get_queue, mock_get_workers):
        """Per-user access grants are checked."""
        self.setup_db()
        self.setup_get_workers(mock_get_workers)
        for cmd, subcmd in [("x", "a"), ("x", "b"), ("z", "a")]:
            mock_get_queue.reset_mock()
            check_and_enqueue_command(
                cmd, subcmd, [], {"org_id": "11", "channel_id": "111", "user_id": "9999"}, MockDispatcher.reset(),
            )
            self.assertEqual(
                MockDispatcher.error, "Access to this bot and/or command is not permitted by user 9999",
            )
            mock_get_queue.assert_not_called()

    def test_not_permitted_channel(self, mock_get_queue, mock_get_workers):
        """Per-channel access grants are checked."""
        self.setup_db()
        self.setup_get_workers(mock_get_workers)
        for cmd, subcmd in [("x", "a"), ("x", "b"), ("z", "a")]:
            mock_get_queue.reset_mock()
            check_and_enqueue_command(
                cmd, subcmd, [], {"org_id": "11", "channel_id": "999", "user_id": "1111"}, MockDispatcher.reset(),
            )
            self.assertEqual(
                MockDispatcher.error, "Access to this bot and/or command is not permitted in channel 999",
            )
            mock_get_queue.assert_not_called()

    def test_not_permitted_organization(self, mock_get_queue, mock_get_workers):
        """Per-organization access grants are checked."""
        self.setup_db()
        self.setup_get_workers(mock_get_workers)
        for cmd, subcmd in [("x", "a"), ("x", "b"), ("z", "a")]:
            mock_get_queue.reset_mock()
            check_and_enqueue_command(
                cmd, subcmd, [], {"org_id": "99", "channel_id": "111", "user_id": "1111"}, MockDispatcher.reset(),
            )
            self.assertEqual(
                MockDispatcher.error, "Access to this bot and/or command is not permitted in organization 99",
            )
            mock_get_queue.assert_not_called()
