"""Test for the netbox_nautobot plugin."""
