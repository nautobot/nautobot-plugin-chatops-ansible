"""Test cases for the Nautobot workers module."""
from django.test import SimpleTestCase

from prybar import dynamic_entrypoint

from netbox_nautobot.workers import parse_command_string, get_workers


class TestFunctions(SimpleTestCase):
    """Test the generic functions provided by netbox_nautobot.workers."""

    def test_parse_command_string(self):
        """Verify that various inputs to parse_command_string() are handled correctly."""
        for string, exp_cmd, exp_sub, exp_params in (
            ("", "", "", []),
            ("   ", "", "", []),
            ("command", "command", "", []),
            ("command   ", "command", "", []),
            ("   command   ", "command", "", []),
            ("command sub-command", "command", "sub-command", []),
            ("command-sub-command", "command", "sub-command", []),
            ("command   sub-command", "command", "sub-command", []),
            ("   command   sub-command   ", "command", "sub-command", []),
            ("command sub-command arg1 arg2", "command", "sub-command", ["arg1", "arg2"]),
            ("command  sub-command  arg1   arg2", "command", "sub-command", ["arg1", "arg2"]),
            ("   command  sub-command  arg1   arg2   ", "command", "sub-command", ["arg1", "arg2"]),
            ("command sub-command arg1 arg2 arg3", "command", "sub-command", ["arg1", "arg2", "arg3"]),
            ("   command sub-command   arg1   arg2   arg3", "command", "sub-command", ["arg1", "arg2", "arg3"]),
        ):
            command, subcommand, params = parse_command_string(string)
            self.assertEqual(command, exp_cmd)
            self.assertEqual(subcommand, exp_sub)
            self.assertEqual(params, exp_params)

    def test_get_workers_multiple_same_file(self):
        """Verify that a single file can contain multiple command workers and their subcommands."""
        with dynamic_entrypoint(
            "nautobot.workers", name="first_command", module="netbox_nautobot.tests.workers.two_commands"
        ):
            with dynamic_entrypoint(
                "nautobot.workers", name="second_command", module="netbox_nautobot.tests.workers.two_commands"
            ):
                workers = get_workers()

                # Make sure both commands and both subcommands were loaded

                self.assertIn("first_command", workers)
                self.assertIn("function", workers["first_command"])
                self.assertTrue(callable(workers["first_command"]["function"]))
                self.assertIn("subcommands", workers["first_command"])
                self.assertIn("first-subcommand", workers["first_command"]["subcommands"])
                self.assertIn("worker", workers["first_command"]["subcommands"]["first-subcommand"])
                self.assertTrue(callable(workers["first_command"]["subcommands"]["first-subcommand"]["worker"]))

                self.assertIn("second_command", workers)
                self.assertIn("function", workers["second_command"])
                self.assertTrue(callable(workers["second_command"]["function"]))
                self.assertIn("subcommands", workers["second_command"])
                self.assertIn("second-subcommand", workers["second_command"]["subcommands"])
                self.assertIn("worker", workers["second_command"]["subcommands"]["second-subcommand"])
                self.assertTrue(callable(workers["second_command"]["subcommands"]["second-subcommand"]["worker"]))
