"""NetBox plugin implementing a chatbot."""
__version__ = "0.2.0"


from extras.plugins import PluginConfig


class NetBoxNautobotConfig(PluginConfig):
    """Plugin configuration for the netbox_nautobot plugin."""

    name = "netbox_nautobot"
    verbose_name = "Nautobot"
    version = __version__
    author = "Glenn Matthews"
    author_email = "glenn.matthews@networktocode.com"
    description = "A plugin providing chatbot capabilities."
    base_url = "nautobot"
    required_settings = []
    default_settings = {
        "enable_slack": False,
        "enable_ms_teams": False,
        "enable_webex_teams": False,
        # Should menus, text input fields, etc. be deleted from the chat history after the user makes a selection?
        "delete_input_on_submission": False,
        # Slack-specific settings
        "slack_api_token": None,  # for example, "xoxb-123456"
        "slack_signing_secret": None,
        # Any prefix that's prepended to all slash-commands for this bot and should be stripped away
        # in order to identify the actual command name to be invoked, eg "/nautobot-"
        "slack_slash_command_prefix": "/",
        # Microsoft-Teams-specific settings
        "microsoft_app_id": None,
        "microsoft_app_password": None,
        # WebEx-Teams-specific settings
        "webex_teams_token": None,
        "webex_teams_signing_secret": None,
    }
    min_version = "2.8.1"
    max_version = "2.9.9999"
    caching_config = {}

    def ready(self):
        """Function invoked after all plugins have been loaded."""
        super().ready()
        # pylint: disable=import-outside-toplevel
        from netbox_metrics_ext import register_metric_func
        from .metrics import metric_commands

        register_metric_func(metric_commands)


config = NetBoxNautobotConfig  # pylint:disable=invalid-name
