"""Plugin additions to the NetBox navigation menu."""

from extras.plugins import PluginMenuItem, PluginMenuButton
from utilities.choices import ButtonColorChoices

menu_items = (
    PluginMenuItem(
        link="plugins:netbox_nautobot:accessgrant_list",
        link_text="Access Grants",
        permissions=["netbox_nautobot.view_accessgrant"],
        buttons=(
            PluginMenuButton(
                link="plugins:netbox_nautobot:accessgrant_add",
                title="Add",
                icon_class="fa fa-plus",
                color=ButtonColorChoices.GREEN,
                permissions=["netbox_nautobot.add_accessgrant"],
            ),
        ),
    ),
    PluginMenuItem(
        link="plugins:netbox_nautobot:home",
        link_text="Command Usage Records",
        permissions=["netbox_nautobot.view_commandlog"],
    ),
)
