"""Django table classes for Nautobot."""

from django_tables2 import TemplateColumn

from utilities.tables import BaseTable, ToggleColumn

from .models import CommandLog, AccessGrant


class CommandLogTable(BaseTable):
    """Table for rendering a listing of CommandLog entries."""

    runtime = TemplateColumn(template_code="{{ record.runtime | shorter_timedelta }}")

    platform = TemplateColumn(
        template_code='<span class="label" style="background-color: #{{ record.platform_color }}">{{ record.platform }}</span>'
    )

    command = TemplateColumn(template_code='<span style="font-family: monospace">{{ record.command }}</span>')
    subcommand = TemplateColumn(template_code='<span style="font-family: monospace">{{ record.subcommand }}</span>')

    class Meta(BaseTable.Meta):
        """Metaclass attributes of CommandLogTable."""

        model = CommandLog
        fields = ("start_time", "runtime", "platform", "user_name", "command", "subcommand")


class AccessGrantTable(BaseTable):
    """Table for rendering a listing of AccessGrant entries."""

    pk = ToggleColumn()

    command = TemplateColumn(template_code='<span style="font-family: monospace">{{ record.command }}</span>')

    subcommand = TemplateColumn(template_code='<span style="font-family: monospace">{{ record.subcommand }}</span>')

    grant_type = TemplateColumn(template_code='<span class="label label-success">{{ record.grant_type }}</span>')

    value = TemplateColumn(template_code='<span style="font-family: monospace">{{ record.value }}</span>')

    actions = TemplateColumn(
        template_code="""
<a href="{% url 'plugins:netbox_nautobot:accessgrant_changelog' pk=record.pk %}" class="btn btn-default btn-xs" title="Change log"><span class="fa fa-history"></span></a>
{% if perms.netbox_nautobot.change_accessgrant %}
<a href="{% url 'plugins:netbox_nautobot:accessgrant_edit' pk=record.pk %}" class="btn btn-xs btn-warning"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
{% endif %}""",
        attrs={"td": {"class": "text-right noprint"}},
        verbose_name="",
    )

    class Meta(BaseTable.Meta):
        """Metaclass attributes of AccessGrantTable."""

        model = AccessGrant
        fields = ("pk", "command", "subcommand", "grant_type", "name", "value", "actions")
        default_columns = ("pk", "command", "subcommand", "grant_type", "name", "actions")
