"""Utility functions for API view implementations."""

import logging

from django.db.models import Q
from django.http import HttpResponse
from django_rq import get_queue

from netbox_nautobot.choices import AccessGrantTypeChoices
from netbox_nautobot.models import AccessGrant
from netbox_nautobot.workers import get_workers

logger = logging.getLogger(__name__)


def check_and_enqueue_command(command, subcommand, params, context, dispatcher_class):
    """Check whether the given command is permitted by any access grants, and enqueue it if permitted.

    For a command/subcommand to be permitted, we must have:

    - access grants for each of the AccessGrantTypeChoices (organization, channel, user)
    - that match either this command + subcommand exactly, or this command + "*" subcommand, or "*" command
    - and permit either this (organization, channel, user) exactly, or have a "*" value

    Args:
        command (str): Top-level chatbot command
        subcommand (str): Chatbot subcommand
        params (list): Any parameters of the command/subcommand
        context (dict): Invocation context of the command
        dispatcher_class (class): Dispatcher concrete subclass

    Returns:
      HttpResponse
    """
    access_grants = AccessGrant.objects.filter(
        Q(command="*") | Q(command=command, subcommand="*") | Q(command=command, subcommand=subcommand),
    )

    dispatcher = dispatcher_class(context)

    org_grants = access_grants.filter(grant_type=AccessGrantTypeChoices.TYPE_ORGANIZATION)
    if "org_id" not in context or not org_grants.filter(Q(value="*") | Q(value=context["org_id"])):
        label = context.get("org_id", "unspecified")
        if "org_name" in context:
            label += f" ({context['org_name']})"
        logger.warning("Blocked %s %s: organization %s is not granted access", command, subcommand, label)
        dispatcher.send_error(f"Access to this bot and/or command is not permitted in organization {label}")
        return HttpResponse()

    chan_grants = access_grants.filter(grant_type=AccessGrantTypeChoices.TYPE_CHANNEL)
    if "channel_id" not in context or not chan_grants.filter(Q(value="*") | Q(value=context["channel_id"])):
        label = context.get("channel_id", "unspecified")
        if "channel_name" in context:
            label += f" ({context['channel_name']})"
        logger.warning("Blocked %s %s: channel %s is not granted access", command, subcommand, label)
        dispatcher.send_error(f"Access to this bot and/or command is not permitted in channel {label}")
        return HttpResponse()

    user_grants = access_grants.filter(grant_type=AccessGrantTypeChoices.TYPE_USER)
    if "user_id" not in context or not user_grants.filter(Q(value="*") | Q(value=context["user_id"])):
        label = context.get("user_id", "unspecified")
        if "user_name" in context:
            label += f" ({context['user_name']})"
        logger.warning("Blocked %s %s: user %s is not granted access", command, subcommand, label)
        dispatcher.send_error(f"Access to this bot and/or command is not permitted by user {label}")
        return HttpResponse()

    # If we made it here, we're permitted. Enqueue it for the worker
    workers = get_workers()
    if command not in workers or "function" not in workers[command] or not callable(workers[command]["function"]):
        logger.error("Invalid/unknown command '%s'. Check workers:\n%s", command, workers)
        dispatcher.send_error(f"Something has gone wrong; I don't know how to handle command '{command}'.")
        return HttpResponse()

    get_queue("default").enqueue(
        workers[command]["function"], subcommand, params=params, dispatcher_class=dispatcher_class, context=context,
    )
    return HttpResponse()
