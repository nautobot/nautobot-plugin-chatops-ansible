"""Views module for the netbox_nautobot NetBox plugin.

The views implemented in this module act as endpoints for various chat platforms
to send requests and notifications to.
"""

from django.contrib.auth.mixins import PermissionRequiredMixin
from django.shortcuts import render
from django.views import View
from django.template.defaulttags import register

from django_tables2 import RequestConfig

from utilities.paginator import EnhancedPaginator, get_paginate_count
from utilities.views import ObjectListView, ObjectEditView, BulkDeleteView

from netbox_nautobot.workers import get_workers
from netbox_nautobot.models import CommandLog, AccessGrant
from netbox_nautobot.filters import CommandLogFilter, AccessGrantFilter
from netbox_nautobot.forms import AccessGrantFilterForm, AccessGrantForm
from netbox_nautobot.tables import CommandLogTable, AccessGrantTable


@register.filter
def shorter_timedelta(timedelta):
    """Render a timedelta as "HH:MM:SS.4" instead of "HH:MM:SS.456789".

    Note that we don't bother with rounding.
    """
    prefix, microseconds = str(timedelta).split(".", 1)
    deciseconds = int(microseconds) // 100_000
    return f"{prefix}.{deciseconds}"


class NautobotHomeView(PermissionRequiredMixin, View):
    """Homepage view for Nautobot."""

    permission_required = "netbox_nautobot.view_commandlog"
    http_method_names = ["get"]

    def get(self, request, *args, **kwargs):
        """Render the home page for Nautobot."""
        # get_workers will populate COMMANDS for us
        commands = dict(get_workers())
        logs = CommandLog.objects.all().order_by("-start_time")

        # Summarize the number of times each command/subcommand has been called
        for command_name, command_data in commands.items():
            commands[command_name]["count"] = logs.filter(command=command_name).count()

            for subcommand_name in command_data["subcommands"]:
                commands[command_name]["subcommands"][subcommand_name]["count"] = logs.filter(
                    command=command_name, subcommand=subcommand_name
                ).count()

        # Support sorting, filtering, and pagination of the table
        queryset = CommandLogFilter(request.GET, logs).qs
        table = CommandLogTable(queryset)
        RequestConfig(
            request, paginate={"paginator_class": EnhancedPaginator, "per_page": get_paginate_count(request)}
        ).configure(table)

        return render(request, "nautobot/home.html", {"commands": commands, "table": table})


class AccessGrantListView(PermissionRequiredMixin, ObjectListView):
    """View for listing all extant AccessGrants."""

    permission_required = "netbox_nautobot.view_accessgrant"
    queryset = AccessGrant.objects.all().order_by("command")
    filterset = AccessGrantFilter
    filterset_form = AccessGrantFilterForm
    table = AccessGrantTable
    template_name = "nautobot/access_grant_list.html"


class AccessGrantCreateView(PermissionRequiredMixin, ObjectEditView):
    """View for creating a new AccessGrant."""

    permission_required = "netbox_nautobot.add_accessgrant"
    model = AccessGrant
    queryset = AccessGrant.objects.all()
    model_form = AccessGrantForm
    template_name = "nautobot/access_grant_edit.html"
    default_return_url = "plugins:netbox_nautobot:accessgrant_list"


class AccessGrantView(AccessGrantCreateView):
    """View for editing an existing AccessGrant."""

    permission_required = "netbox_nautobot.change_accessgrant"


class AccessGrantBulkDeleteView(PermissionRequiredMixin, BulkDeleteView):
    """View for deleting one or more AccessGrant records."""

    permission_required = "netbox_nautobot.delete_accessgrant"
    queryset = AccessGrant.objects.filter()
    table = AccessGrantTable
    default_return_url = "plugins:netbox_nautobot:accessgrant_list"
